
-- --------------------------------------------------------

--
-- Table structure for table `SSFundApplicants`
--

CREATE TABLE `SSFundApplicants` (
  `SerialNo` int NOT NULL,
  `District` varchar(10) NOT NULL DEFAULT 'Gampaha',
  `DivSec` varchar(20) NOT NULL DEFAULT 'Divulapitiya',
  `Zone` text NOT NULL,
  `ForceNo` int NOT NULL,
  `Village` text NOT NULL,
  `GNDomain` text NOT NULL,
  `SSOwnershipNo` text NOT NULL,
  `Name` text NOT NULL,
  `Address` text NOT NULL,
  `Successer` text NOT NULL,
  `HomeNo` text NOT NULL,
  `Banned` tinyint(1) NOT NULL DEFAULT '0',
  `Deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
