
-- --------------------------------------------------------

--
-- Table structure for table `SipdoraScholarship`
--

CREATE TABLE `SipdoraScholarship` (
  `SerialNo` int NOT NULL,
  `Name` text NOT NULL,
  `Gender` enum('Male','Female','Other') NOT NULL,
  `Ethnicity` enum('Sinhala','Tamil','Muslim','Burger') NOT NULL,
  `Guardian` text NOT NULL,
  `SpeciallyAbled` enum('True','False') NOT NULL,
  `Stream` enum('Biology','Maths','ICT','Commerce','Art','Technology','Agri') NOT NULL,
  `NIC` varchar(15) NOT NULL,
  `School` text NOT NULL,
  `Address` text NOT NULL,
  `Bank` text NOT NULL,
  `SisurakaAcNo` varchar(10) NOT NULL,
  `Deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
