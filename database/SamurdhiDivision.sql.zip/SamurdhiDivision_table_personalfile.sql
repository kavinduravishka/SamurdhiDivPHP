
-- --------------------------------------------------------

--
-- Table structure for table `personalfile`
--

CREATE TABLE `personalfile` (
  `member_id` int NOT NULL,
  `nic_number` varchar(12) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(200) NOT NULL,
  `service` varchar(100) NOT NULL,
  `date_appointed` date NOT NULL,
  `date_of_birth` date NOT NULL,
  `date_of_pension` date NOT NULL,
  `w_op_number` int NOT NULL,
  `is_deleted` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `personalfile`
--

INSERT INTO `personalfile` (`member_id`, `nic_number`, `name`, `designation`, `service`, `date_appointed`, `date_of_birth`, `date_of_pension`, `w_op_number`, `is_deleted`) VALUES
(1, '', 'Mr.J.Kanuradasa', 'Public Management Assistant', 'PMA(Class 2)', '2019-01-10', '1990-12-05', '2050-12-05', 2222222, 0),
(2, '', 'Mrs.L.Madurangi', 'Public Management Assistant', 'PMA(Class 3)', '2018-01-10', '1990-03-05', '2050-03-05', 3333333, 0),
(3, '1234', 'abcd', 'abcd', 'abcd', '2020-04-03', '2020-04-03', '2020-04-03', 1234, 0),
(4, '', 'Mr. J.C.Wijethunga', 'Management Assistant', 'PMA', '2020-02-02', '1996-12-09', '2056-12-09', 2342342, 0),
(5, '', 'Mr.K.K.Amarasinghe', 'Public Management Assistant', 'PMA(Class 3)', '2017-05-05', '1980-11-23', '2060-11-23', 1111111, 0),
(6, '123456785V', 'Mrs. D.Dharamsena', 'Clerk', 'PMA', '2020-05-13', '2020-04-28', '2020-05-06', 1234567, 0);
