
--
-- Indexes for dumped tables
--

--
-- Indexes for table `CBOMemberDetailes`
--
ALTER TABLE `CBOMemberDetailes`
  ADD UNIQUE KEY `NIC` (`NIC`);

--
-- Indexes for table `CommunityBasedOrganizations`
--
ALTER TABLE `CommunityBasedOrganizations`
  ADD UNIQUE KEY `RegNo` (`RegNo`);

--
-- Indexes for table `detailsofbenificiaries`
--
ALTER TABLE `detailsofbenificiaries`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `LottaryFundRecord`
--
ALTER TABLE `LottaryFundRecord`
  ADD UNIQUE KEY `NIC` (`NIC`);

--
-- Indexes for table `personalfile`
--
ALTER TABLE `personalfile`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `SipdoraScholarship`
--
ALTER TABLE `SipdoraScholarship`
  ADD UNIQUE KEY `SerialNo` (`SerialNo`);

--
-- Indexes for table `SSFundApplicants`
--
ALTER TABLE `SSFundApplicants`
  ADD UNIQUE KEY `SerialNo` (`SerialNo`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detailsofbenificiaries`
--
ALTER TABLE `detailsofbenificiaries`
  MODIFY `Serial_No` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `personalfile`
--
ALTER TABLE `personalfile`
  MODIFY `member_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `SipdoraScholarship`
--
ALTER TABLE `SipdoraScholarship`
  MODIFY `SerialNo` int NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SSFundApplicants`
--
ALTER TABLE `SSFundApplicants`
  MODIFY `SerialNo` int NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;