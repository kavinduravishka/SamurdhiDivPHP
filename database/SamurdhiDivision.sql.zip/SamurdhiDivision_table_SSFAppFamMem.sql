
-- --------------------------------------------------------

--
-- Table structure for table `SSFAppFamMem`
--

CREATE TABLE `SSFAppFamMem` (
  `OwnershipNo` varchar(40) NOT NULL,
  `Name` text NOT NULL,
  `Gender` enum('Male','Female','Other') NOT NULL,
  `MaritialState` tinyint(1) NOT NULL,
  `BDay` date NOT NULL,
  `Age` int NOT NULL,
  `RelToBenif` varchar(30) NOT NULL,
  `NIC` varchar(15) NOT NULL,
  `Profession` varchar(30) NOT NULL,
  `Deleted` tinyint(1) NOT NULL DEFAULT '0',
  `Dead` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
