
-- --------------------------------------------------------

--
-- Table structure for table `LottaryFundRecord`
--

CREATE TABLE `LottaryFundRecord` (
  `NIC` varchar(13) NOT NULL,
  `Name` text NOT NULL,
  `Address` text,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
