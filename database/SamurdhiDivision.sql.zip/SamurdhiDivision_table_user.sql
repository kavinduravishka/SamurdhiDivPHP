
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_deleted` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_name`, `email`, `password`, `last_login`, `is_deleted`) VALUES
(1, 'officer4', 'officer4@gmail.com', '37fa265330ad83eaa879efb1e2db6380896cf639', '2020-05-04 17:16:21', 0),
(2, 'officer1', 'officer1@gmail.com', '37fa265330ad83eaa879efb1e2db6380896cf639', '2020-05-13 00:00:00', 0),
(3, 'officer2', 'officer2@gmail.com', '37fa265330ad83eaa879efb1e2db6380896cf639', '2020-05-13 00:00:00', 0),
(4, 'officer3', 'officer3@gmail.com', '37fa265330ad83eaa879efb1e2db6380896cf639', '2020-05-13 00:00:00', 0),
(5, 'officer5', 'officer5@gmail.com', '37fa265330ad83eaa879efb1e2db6380896cf639', '2020-05-13 00:00:00', 0);
